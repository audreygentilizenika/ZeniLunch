# ZeniLunch
Trop dur de choisir où manger le midi, enfin ça c'était avant cette application Android.

Lien vers la maquette Figma : https://www.figma.com/file/zTOajuYZ2MYCohjXHeSJuA/ZeniLunch?node-id=0%3A1&t=MHQir7ZKVIQ3yg5d-1